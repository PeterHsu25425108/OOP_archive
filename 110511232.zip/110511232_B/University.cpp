#include<iostream>
#include<sstream>
#include<fstream>
#include<string>
#include<cstdlib>
#include"University.h"
#include"Applicant.h"
using namespace std;

/*    private:
        int n_universities;
        string serial_numer;
        string name;
        int* criteria;
        double* weight;
        int limit;*/

int University::n_universities=0;

void University::match_apps()
{
    cout<<"_University"<<endl;
    cout<<"Numer "<<serial_number<<endl;
    cout<<"Name "<<name<<endl;
    cout<<"Match Result "<<match_result<<endl;
    cout<<endl;
}

void University::match_apps(ostream& out)
{
    out<<"_University"<<endl;
    out<<"Numer "<<serial_number<<endl;
    out<<"Name "<<name<<endl;
    out<<"Match Result "<<match_result<<endl;
    out<<endl;
}

int University::getCriteria(int k)
{
    return criteria[k];
}

void University::addPassApp(Applicant* added)
{
    passApp[n_pass]=added;
    n_pass++;
}

void University::sortPassApp(int uni_idx)
{
    if(n_pass==0)
    {
//        cout<<"No one pass(sort)!!"<<endl;
        return;
    }
    //sort to ascending
    for(int j=1;j<n_pass;j++)
    {
        Applicant* key=passApp[j];
        int i=j-1;
        while((i>=0)&&prior(passApp[i],key,uni_idx))
        {
            passApp[i+1]=passApp[i];
            i-=1;
        }
        passApp[i+1]=key;
    }

    //invert the order
    for(int i=0;i<n_pass/2;i++)
    {
        Applicant* temp=passApp[i];
        passApp[i]=passApp[n_pass-1-i];
        passApp[n_pass-1-i]=temp;
    }
}

void University::deleteExtraApp()
{
    if(n_pass==0)
    {
//        cout<<"No one pass(delete)!!"<<endl;
        return;
    }
    int idx=n_pass;
    while((passApp!=NULL)&&(idx<1000))
    {
        passApp[idx]=NULL;
        idx++;
    }
    n_pass=limit;
}

void University::setMatchResult(Applicant* app_pt,int uni_idx)
{
    if(match_result.length()!=0)
        match_result+=" ";
    match_result+=app_pt->serial_number;
}

bool University::extraApp()
{
    return(n_pass>limit);
}

bool prior(Applicant* a,Applicant* key,int uni_idx)
{
    bool x = (a->getFinalScore(uni_idx)>key->getFinalScore(uni_idx));
    bool y = (a->getSerialNumber()<key->getSerialNumber());
    if(x)
        return true;
    else if(a->getFinalScore(uni_idx)==key->getFinalScore(uni_idx))
        return y;
    else
        return false;
}

University::University()
{
    serial_number="";
    name="";
/*    criteria = new int [5];
    weight = new double [5];*/
/*    for(int i=0;i<5;i++)
    {
        criteria[i]=-1;
        weight[i]=-1;
    }*/
    limit=0;
    n_pass=0;
    match_result="";
}

University::University(const University& copied)
{
    serial_number=copied.serial_number;
    name=copied.name;
/*    criteria = new int [5];
    weight = new double [5];*/
    for(int i=0;i<5;i++)
    {
        criteria[i]=copied.criteria[i];
        weight[i]=copied.weight[i];
    }
    limit=copied.limit;
    for(int i=0;i<1000;i++)
    {
        passApp[i]=copied.passApp[i];
    }
    n_pass=copied.n_pass;
    match_result=copied.match_result;
}

University::~University()
{
/*    delete [] criteria;
    criteria=NULL;
    delete [] weight;
    weight=NULL;*/
}

int Standard(int i,int criteria_i)//i: subject index, score_i: criteria index
{
    int a[5][5]={{3,4,6,9,11},
                 {8,9,11,12,13},
                 {4,5,8,12,13},
                 {5,6,8,12,13},
                 {7,8,10,12,13}};
    return a[i][criteria_i];
}

bool University::passCriteria(Applicant app)
{
    for(int i=0;i<5;i++)
    {

//        cout<<"scores["<<i<<"]: "<<app.scores[i]<<endl;
//        cout<<"standard: "<<criteria[i]<<endl;

        if(criteria[i]==-1)
            continue;
        else if(app.scores[i]==-1 && criteria[i]!=-1)
            return false;
        else
        {
            if(criteria[i]>app.scores[i])
                return false;
        }
    }
    return true;
}

double University::weightedSum(Applicant app)
{
    double val=0;
    for(int i=0;i<5;i++)
    {
        if(app.scores[i]!=-1)
        {
            val+=weight[i]*app.scores[i];
        }
    }
    return val;
}

void University::get_Rank5(Applicant* apps)
{
    int n_apps = apps->n_applicants;
//    n_apps=2;

//    cout<<"n_applicant before arr: "<<Applicant::n_applicants<<endl;
    Applicant* arr[n_apps];
//    cout<<"n_applicant after arr: "<<Applicant::n_applicants<<endl;
    for(int i=0;i<n_apps;i++)
    {
//        cout<<"n_applicant before arr["<<i<<"] assignment: "<<Applicant::n_applicants<<endl;
        arr[i]=apps+i; 
//        cout<<"n_applicant after arr["<<i<<"] assignment: "<<Applicant::n_applicants<<endl;
    }

//    cout<<"n_applicant before for: "<<Applicant::n_applicants<<endl;
    //sort arr in ascending order
    for(int j=1;j<n_apps;j++)
    {
        Applicant* key(arr[j]);
        int i=j-1;
        while((i>=0)&&(this->weightedSum((*arr[i]))>this->weightedSum((*key))))
        {
            arr[i+1]=arr[i];
            i-=1;
        }
        arr[i+1]=key; 
    }

    cout<<"_University "<<serial_number<<" "<<name<<":";
    int idx = n_apps-1;
    int n=0;//number of applicants selected
//    cout<<"n_applicant before while: "<<Applicant::n_applicants<<endl;

    string output[n_apps]={"none"};

    while((n<5)&&(idx>=0))
    {
        if(this->passCriteria((*arr[idx])))
        {
            output[n]=arr[idx]->serial_number;
            n++;
        }
        idx--;
    }

    for(int j=1;j<n;j++)
    {
        string key=output[j];
        int i=j-1;
        while((i>=0)&&(stoi(output[i])>stoi(key)))
        {
            output[i+1]=output[i];
            i-=1;
        }
        output[i+1]=key; 
    }   

    for(int i=0;i<n;i++)
    {
        cout<<" "<<output[i];
    }

//    delete [] arr;
//    arr=NULL;

    cout<<endl;
//    cout<<"n_applicant at the end of function: "<<Applicant::n_applicants<<endl;
}

//void match_apps();

int University::getSerialNumber()
{
    return stoi(serial_number);
}

ostream& operator<<(ostream& out, const University& unis)
{
    out<<"_University"<<endl;
    out<<"Numer "<<unis.serial_number<<endl;
    out<<"Name "<<unis.name<<endl;
    out<<"Enrollment Limit "<<unis.limit<<endl;
    return out;
}

istream& operator>>(istream& in, University& unis)
{
    string mes;
    char c;
    stringstream ss;

    //serial_number
    in.get(c);
    getline(in,mes,',');
    unis.serial_number=mes;
    in.get(c);

    //name
    getline(in,mes,',');
    unis.name=mes;
    in.get(c);

    //criteria
    in.get(c);//absorb (
    getline(in,mes,')');
    ss.str(mes);

    for(int i=0;i<5;i++)
    {
        ss>>mes;
        if(mes=="X")
            unis.criteria[i]=-1;
        else
        {
            unis.criteria[i]=Standard(i,stoi(mes));
        }
    }
    ss.clear();
    in.get(c);
    in.get(c);

    //weight
    in.get(c);
    getline(in,mes,')');
    ss.str(mes);
    int weight_number=0;
    while(ss>>mes)
    {
        unis.weight[weight_number]=stod(mes);
        weight_number++;
    }
    for(int i=weight_number;i<6;i++)
    {
        unis.weight[i]=-1;
    }
    ss.clear();
    in.get(c);
    in.get(c);

    //limit
    getline(in,mes);
    unis.limit=stoi(mes);
    return in;
}

void University::operator=(const University& copied)
{
    //cout<<"enter assign"<<endl;
    serial_number=copied.serial_number;
    name=copied.name;
    for(int i=0;i<5;i++)
    {
        criteria[i]=copied.criteria[i];
        weight[i]=copied.weight[i];
    }
    limit=copied.limit;
    //cout<<"all assignsd"<<endl;
    for(int i=0;i<1000;i++)
    {
        passApp[i]=copied.passApp[i];
    }
    n_pass=copied.n_pass;
    match_result=copied.match_result;
}
