#ifndef A_H
#define A_H
#include<string>
#include<sstream>
#include<fstream>
#include<iostream>
#include<cstdlib>
//#include"University.h"
using namespace std;

class University;

class Applicant
{
    friend class University;
    private:
        string serial_number;
        string name;
        int scores[5]={-1};
        int wishlist[6]={-1};//The unfilled term will be -1: (1,6)=(1,6,-1,-1...,-1)
        double finalScores[1000]={-1};
        string uni;
        int best_uni_idx;

        static int chinese_total;
        static int math_total;
        static int science_highest;
        static int english_highest;
    public:
        static int n_applicants;
        Applicant();
        Applicant(const Applicant&);
        ~Applicant();
        //calculate and print the avg
        static void get_Chinese_Avg();
        static void get_Math_Avg();
        static void get_Science_Highest();
        static void get_English_Highest();
        static void addScore(int i,int score);
        int getSerialNumber();
        void match_uni();
        void match_uni(ostream&);

        string getName()
        {
            return name;
        }

//        friend write_file(char*,Applicant*,Univrsity*);
//        friend match_func(Applicant*,University*);
        friend ostream& operator<<(ostream& out,const Applicant& app);
        friend istream& operator>>(istream& in,Applicant& app);
        void operator=(const Applicant&);

        int getScore(int k);
        void setFinalScore(int j,double score);
        int getWishList(int k);
        double getFinalScore(int uni_idx);
        void setUni(University u);
        bool betterUni(University u,int uni_idx);
        int findWishIdx(University u,int uni_idx);
};

#endif
