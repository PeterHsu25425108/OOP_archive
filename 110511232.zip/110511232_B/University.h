#ifndef U_H
#define U_H
#include<string>
#include<sstream>
#include<fstream>
#include<iostream>
#include<cstdlib>
//#include"Applicant.h"
using namespace std;

class Applicant;

class University
{
    friend class Applicant;
    private:
        string serial_number;
        string name;
        int criteria[5]={-1};
        double weight[5]={-1};
        int limit;
        string match_result;
    public:
        Applicant* passApp[1000]={NULL};
        int n_pass;

        double weightedSum(Applicant);
        static int n_universities;
        int getSerialNumber();
        University();
        University(const University&);
        ~University();
        bool passCriteria(Applicant);
        void get_Rank5(Applicant*);
        void match_apps();
        void match_apps(ostream&);
        //friend void sort_unis(University* unis);
//        friend void match_func(Applicant*,University*);
        friend ostream& operator<<(ostream& out, const University& unis);
        friend istream& operator>>(istream& in, University& unis);
        void operator=(const University&);

        int getCriteria(int k);
        void addPassApp(Applicant*);
        void sortPassApp(int uni_idx);
        void deleteExtraApp();
        void setMatchResult(Applicant*,int);
        bool extraApp();
};

bool prior(Applicant* a,Applicant* key,int uni_idx);

#endif
