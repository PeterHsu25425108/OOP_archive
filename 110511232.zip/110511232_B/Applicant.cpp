#include<iostream>
#include<sstream>
#include<fstream>
#include<string>
#include<cstdlib>
#include"University.h"
#include"Applicant.h"
using namespace std;

/*    private:
        int n_applicants;
        string serial_numer;
        string name;
        int* scores;
        int* wishlist;*/

int Applicant::n_applicants=0;
int Applicant::chinese_total=0;
int Applicant::math_total=0;
int Applicant::science_highest=0;
int Applicant::english_highest=0;

void Applicant::match_uni()
{
    cout<<"_Applicant"<<endl;
    cout<<"Number "<<serial_number<<endl;
    cout<<"Name "<<name<<endl;
    cout<<"Match Result "<<uni<<endl<<endl;
}

void Applicant::match_uni(ostream& out)
{
    out<<"_Applicant"<<endl;
    out<<"Number "<<serial_number<<endl;
    out<<"Name "<<name<<endl;
    out<<"Match Result "<<uni<<endl<<endl;
}

bool Applicant::betterUni(University u,int uni_idx)
{
    if(uni.length()==0)
    {
        best_uni_idx=uni_idx;
        return true;
    }
    else if(this->findWishIdx(u,uni_idx)<best_uni_idx)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int Applicant::findWishIdx(University u,int uni_idx)
{
    for(int i=0;i<6;i++)
    {
        if(uni_idx==wishlist[i])
            return i;
        else if(wishlist[i]==-1)
        {
            cout<<"cannot find "<<u.name<<"("<<uni_idx<<"th) in "<<name<<"'s wishlist"<<endl;
            return 0;
        }
    } 
}

int Applicant::getScore(int k)
{
    return scores[k];
}

void Applicant::setFinalScore(int j,double score)
{
    finalScores[j]=score;
}

int Applicant::getWishList(int k)
{
    return wishlist[k];
}

double Applicant::getFinalScore(int uni_idx)
{
    return finalScores[uni_idx];
}

void Applicant::setUni(University u)
{
    uni=u.name;
}

void Applicant::addScore(int i,int score)
{
    switch(i)
    {
        case 1:
            chinese_total+=score;
            break;
        case 0:
            math_total+=score;
            break;
        case 3:
            science_highest=((score>science_highest) ? score : science_highest);
            break;
        case 2:
            english_highest=((score>english_highest) ? score : english_highest);
            break;
        default:
            ;
    }
}

Applicant::Applicant()
{
    n_applicants=0;
    serial_number="";
    name="";
    uni="";
    best_uni_idx=0;
//    scores=new int [5];
//    wishlist=new int [6];
/*    for(int i=0;i<5;i++)
        scores[i]=-1;
    for(int i=0;i<6;i++)
        wishlist[i]=-1;*/
}

Applicant::Applicant(const Applicant& copied)
{
    serial_number=copied.serial_number;
    name=copied.name;
    uni=copied.uni;
    for(int i=0;i<5;i++)
    {
        scores[i]=copied.scores[i];
    }
    for(int i=0;i<1000;i++)
    {
        finalScores[i]=copied.finalScores[i];
    }
    for(int i=0;i<6;i++)
    {
        wishlist[i]=copied.wishlist[i];
    }
    best_uni_idx=copied.best_uni_idx;
}

Applicant::~Applicant()
{
/*    delete [] scores;
    scores = NULL;
    delete [] wishlist;
    wishlist=NULL;*/
//    cout<<endl<<name<<" destructed"<<endl;
}

int Applicant::getSerialNumber()
{
    return stoi(serial_number);
}

//calculate and print the avg
void Applicant::get_Chinese_Avg()
{
    cout<<"Chinese Average: "<<(double)chinese_total/(double)n_applicants<<endl;
}
void Applicant::get_Math_Avg()
{
    cout<<"Math Average: "<<(double)math_total/(double)n_applicants<<endl;
}
void Applicant::get_Science_Highest()
{
    cout<<"Science Highest: "<<science_highest<<endl;
}
void Applicant::get_English_Highest()
{
    cout<<"English Highest: "<<english_highest<<endl;
}

//        void match_uni();

ostream& operator<<(ostream& out,const Applicant& app)
{
    out<<"_Applicant"<<endl;
    out<<"Number "<<app.serial_number<<endl;
    out<<"Name "<<app.name<<endl;
    int subject_count=75;
    int score_count = 0;
    for(int i=0;i<5;i++)
    {
        if(app.scores[i]==-1)
        {
            subject_count-=15;
            continue;
        }
        switch(i)
        {
            case 0:
                out<<"Math ";
                break;
            case 1:
                out<<"Chinese ";
                break;
            case 2:
                out<<"English ";
                break;    
            case 3:
                out<<"Science ";
                break;
            case 4:
                out<<"Society ";
                break;
            default:
                cerr<<"Invalid score index!!"<<endl;
        }
        out<<app.scores[i]<<endl;
        score_count+=app.scores[i];
    }
    out<<"Total: "<<score_count<<"/"<<subject_count<<endl;
    return out;
}

istream& operator>>(istream& in,Applicant& app)
{
    string mes;
    char c;
    stringstream ss;

    //serial_number
    in.get(c);
    getline(in,mes,',');
    app.serial_number=mes;
    in.get(c);

    //name
    getline(in,mes,',');
    app.name=mes;
    in.get(c);

    //scores
    in.get(c);//absorb (
    getline(in,mes,')');
    ss.str(mes);

    for(int i=0;i<5;i++)
    {
        ss>>mes;
        if(mes=="X")
            app.scores[i]=-1;
        else
        {
            app.scores[i]=stoi(mes);
            app.addScore(i,stoi(mes));
        }
    }
    ss.clear();
    in.get(c);
    in.get(c);

    //wishlist&wish_number
    in.get(c);
    getline(in,mes,')');
    ss.str(mes);
    int wish_number=0;
    while(ss>>mes)
    {
        app.wishlist[wish_number]=stoi(mes)-1;
        wish_number++;
    }
    for(int i=wish_number;i<6;i++)
    {
        app.wishlist[i]=-1;
    }
    ss.clear();
    return in;
}

void Applicant::operator=(const Applicant& copied)
{
//    cout<<"enter assign"<<endl;
    serial_number=copied.serial_number;
    name=copied.name;
    for(int i=0;i<5;i++)
    {
//        cout<<"scores"<<i<<" before copy: "<<scores[i]<<endl;
        scores[i]=copied.scores[i];
//        cout<<"scores"<<i<<" after copy: "<<scores[i]<<endl;
    }
    for(int i=0;i<6;i++)
    {
//        cout<<"wishlist"<<i<<" before copy: "<<wishlist[i]<<endl;
        wishlist[i]=copied.wishlist[i];
//        cout<<"wishlist"<<i<<" after copy: "<<wishlist[i]<<endl;
    }
//    cout<<"all assigned"<<endl;
    uni=copied.uni;
    for(int i=0;i<5;i++)
    {
        scores[i]=copied.scores[i];
        finalScores[i]=copied.finalScores[i];
    }
    for(int i=0;i<1000;i++)
    {
        finalScores[i]=copied.finalScores[i];
    }
    best_uni_idx=copied.best_uni_idx;
}
