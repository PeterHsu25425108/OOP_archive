#include <iostream>
#include <cstring>
#include <fstream>
#include"Applicant.h"
#include"University.h"
/*
#include “Applicant.h”
#include “University.h”
*/
using namespace std;
// Q1
void read_file(string filename, Applicant** apps, University** unis)
{
    ifstream in_file(filename.c_str());
    string input;
    (*apps)=new Applicant [100000];
    (*unis)=new University [100000];
    while(getline(in_file,input))
    {
        stringstream ss(input);
        ss>>input;
        if(input=="U:")
        {
            ss>>(*unis)[(*unis)->n_universities];
            (*unis)->n_universities++;
        }
        else if(input=="A:")
        {
            ss>>(*apps)[(*apps)->n_applicants];
            (*apps)->n_applicants++;
        }
        ss.clear();
    }

    in_file.close();
}

// Q1
void sort_apps(Applicant* apps)
{
    for(int j=1;j<apps->n_applicants;j++)
    {
//        cout<<"key = apps["<<j<<"]"<<endl;
        Applicant key(apps[j]);
        int i=j-1;
        while((i>=0)&&(apps[i].getSerialNumber())>key.getSerialNumber())
        {
//            cout<<"apps["<<i+1<<"]=apps["<<i<<"]"<<endl;
            apps[i+1]=apps[i];
            i-=1;
        }
//        cout<<"apps["<<i+1<<"]=key"<<endl;
        apps[i+1]=key;
    }
//    cout<<"sort app completed"<<endl;
}

// Q1
void sort_unis(University* unis)
{
//    cout<<"sort unis start"<<endl;
    for(int j=1;j<unis->n_universities;j++)
    {
        University key(unis[j]);
        int i=j-1;
//        cout<<"assign key"<<endl;
        while((i>=0)&&(unis[i].getSerialNumber()>key.getSerialNumber()))
        {
//            cout<<"while unis"<<endl;
            unis[i+1]=unis[i];
//            cout<<"exchange"<<endl;
            i-=1;
        }
        unis[i+1]=key;
//        cout<<"unis[i+1] completed"<<endl;
    }
//    cout<<"sort unis completed"<<endl;
}

// Q3 You need to delete the memory in the write file
void write_file(string filename, Applicant** apps_pt, University** unis_pt)
{
    Applicant* apps=(*apps_pt);
    University* unis=(*unis_pt);

    ofstream out_file(filename.c_str());
    for(int i=0;i<apps->n_applicants;i++)
        apps[i].match_uni(out_file);

    for(int i=0;i<unis->n_universities;i++)
        unis[i].match_apps(out_file);

    delete [] (*apps_pt);
    (*apps_pt)=NULL;
    delete [] (*unis_pt);
    (*unis_pt)=NULL;
    out_file.close();
}

void match_func(Applicant* apps, University* unis)
{
    int n_apps=apps->n_applicants;
    int n_unis=unis->n_universities;

    //pick apps that pass the criteria of each uni
    for(int i=0;i<n_apps;i++)
    {
        for(int j=0;j<n_unis;j++)
        {
            bool pass=true;
            for(int k=0;k<5;k++)
            {
                if(unis[j].getCriteria(k)==-1)
                    continue;
                else if(unis[j].getCriteria(k)>apps[i].getScore(k))
                {
                    pass=false;
                    apps[i].setFinalScore(j,-1);
                    break;
                }

                if(pass)
                {
                    double final_score=unis[j].weightedSum(apps[i]);
                    apps[i].setFinalScore(j,final_score);
                }
            } 
        }
    }

    //update passApp and n_pass
    for(int i=0;i<n_apps;i++)
    {
        for(int k=0;apps[i].getWishList(k)!=-1;k++)
        {
            int uni_idx=apps[i].getWishList(k);
//            cout<<apps[i].getName()<<"'s "<<i+1<<"th wish: "<<uni_idx<<endl;
            if(apps[i].getFinalScore(uni_idx)!=-1)
                unis[uni_idx].addPassApp(apps+i);
        }
    }

    //kick out app if n_pass>limit
    for(int j=0;j<n_unis;j++)
    {
        unis[j].sortPassApp(j);
        if(unis[j].extraApp())
        {
            unis[j].deleteExtraApp();
        }
        for(int k=0;k<unis[j].n_pass;k++)
        {
            if(unis[j].passApp[k]->betterUni(unis[j],j))
            {
                unis[j].passApp[k]->setUni(unis[j]);
                unis[j].setMatchResult(unis[j].passApp[k],j);
            }
        }
    }
    
}

int main(int argc, char* argv[]){

    Applicant* my_applicants;
    University* my_universities;

    if(argc < 2){
        cout << "No input file provided." << endl;
        return -1;
    }
    if(argc < 3){
        cout << "No output file provided." << endl;
        return -1;
    }

    //Q1
    read_file(argv[1], &my_applicants, &my_universities);
    sort_apps(my_applicants);
    sort_unis(my_universities);

    cout << my_applicants -> n_applicants << endl;
    for(int i = 0; i < my_applicants -> n_applicants; i++){
        cout << my_applicants[i] << endl;
    }

    cout << my_universities -> n_universities << endl;
    for(int i = 0; i < my_universities -> n_universities; i++){
        cout << my_universities[i] << endl;
    }

    my_applicants->get_Chinese_Avg();
    my_applicants->get_Math_Avg();
    my_applicants->get_Science_Highest();
    my_applicants->get_English_Highest();

    //Q2
    for(int i = 0; i < my_universities -> n_universities; i++){
        my_universities[i].get_Rank5(my_applicants);
    }	

    //Q3
    match_func(my_applicants, my_universities);
    for(int i = 0; i < my_applicants -> n_applicants; i++){
        my_applicants[i].match_uni();
    }

    for(int i = 0; i < my_universities -> n_universities; i++){
        my_universities[i].match_apps();
    }
    write_file(argv[2], &my_applicants, &my_universities);
}  
