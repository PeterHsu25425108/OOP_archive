#include "Minner.hpp"

Minner::Minner()
{
    id=0;
    workType=0;
    computingPower=0;
    miningProcessTimer=0;
    this->revenue = 0;
    this->localTransArr = NULL;
}

Minner::~Minner()
{
    // --------------------- student code ---------------------
    delete [] localTransArr;
    localTransArr=NULL;
    // ===================== student code =====================
}

void Minner::operator=(const Minner& copied)
{
    id=copied.id;
    revenue=copied.revenue;
    computingPower=copied.computingPower;
    miningProcessTimer=copied.miningProcessTimer;
    workType=copied.workType;
    if(localTransArr==NULL)
        return;

    if(localTransArr!=NULL)
    {    
        delete [] localTransArr;
        localTransArr=NULL;
        localTransArr=new Transaction [copied.LOCAL_TRANSVEC_SIZE];
    }

    for(int i=0;i<copied.LOCAL_TRANSVEC_SIZE;i++)
    {
        localTransArr[i]=copied.localTransArr[i];
    }
}

Minner::Minner(const Minner& copied)
{
    id=copied.id;
    revenue=copied.revenue;
    computingPower=copied.computingPower;
    miningProcessTimer=miningProcessTimer;
    workType=copied.workType;
    if(localTransArr==NULL)
        return;

    if(localTransArr!=NULL)
    {    
        delete localTransArr;
        localTransArr=NULL;
        localTransArr=new Transaction [LOCAL_TRANSVEC_SIZE];
    }

    for(int i=0;i<LOCAL_TRANSVEC_SIZE;i++)
    {
        localTransArr[i]=copied.localTransArr[i];
    }
}

void Minner::swap_transaction(Transaction *m1, Transaction *m2) {
    Transaction tmp; 
    tmp.id = m1->id;
    tmp.fee = m1->fee;
    tmp.buyer = m1->buyer;
    tmp.seller = m1->seller;
    tmp.coinAmount = m1->coinAmount;
    tmp.usDollar = m1->usDollar;

    m1->id = m2->id;
    m1->fee = m2->fee;
    m1->buyer = m2->buyer;
    m1->seller = m2->seller;
    m1->coinAmount = m2->coinAmount;
    m1->usDollar = m2->usDollar;

    m2->id = tmp.id;
    m2->fee = tmp.fee;
    m2->buyer = tmp.buyer;
    m2->seller = tmp.seller;
    m2->coinAmount = tmp.coinAmount;
    m2->usDollar = tmp.usDollar;
}


void Minner::set_new_localTransArr(Transaction *transVec, int transVecSize)
{   
    // copy two transactions (LOCAL_TRANSVEC_SIZE) to local transaction arrays according the work type
    // hint: use deep copy method
    
    // --------------------- student code ---------------------
    if(localTransArr!=NULL)
    {
//        cout<<"minner "<<id<<"'s localTransArr isn't NULL when set_new_localTransArr!!"<<endl;
        localTransArr=new Transaction[LOCAL_TRANSVEC_SIZE];
    }
    localTransArr=new Transaction [LOCAL_TRANSVEC_SIZE];

    for(int j=1;j<transVecSize;j++)
    {
        Transaction key=transVec[j];
        int i=j-1;
        while((i>=0)&&(transVec[i].fee>key.fee))
        {
            transVec[i+1]=transVec[i];
            i-=1;
        }
        transVec[i+1]=key;
    }

//    cout<<endl<<"transVect after sorting"<<endl;
/*    for(int i=0;i<transVecSize;i++)
        cout<<transVec[i].id<<" ";
    cout<<endl;*/

    for(int i=0;i<LOCAL_TRANSVEC_SIZE;i++)
    {
        localTransArr[i]=((!workType) ? transVec[i] : transVec[transVecSize-1-i]);
    }

    // ===================== student code =====================
}


bool Minner::check_transactions_in_localTransArr(Transaction *completedTransArr, int completedTransArrSize)
{

    if (this->localTransArr == NULL) {
//        cout<<"not mining"<<endl;
        return false;
    }

    // check if any completed transactions is in local transaction array    
    /* return
     *   true: at least one completed transaction in local transaction array
     *   false: no completed transaction in local transaction array
     */
    // hint: compare transaction id

    // --------------------- student code ---------------------
    for(int i=0;i<completedTransArrSize;i++)
    {
        for(int j=0;j<LOCAL_TRANSVEC_SIZE;j++)
        {
            if(completedTransArr[i].id==localTransArr[j].id)
            {
//                cout<<"the completed trans in minner"<<id<<": "<<localTransArr[j].id<<"th trans"<<endl;
                return true;
            }
        }
    }
//    cout<<"the uncompleted trans in minner"<<id<<": "<<localTransArr[j].id<<"th trans"<<endl; 
    return false;

    // ===================== student code =====================
}


void Minner::clear_localTransArr(bool changeMinnerType)
{
    /* delete clear_localTransArr, reset mining process timer
     * and change work type if changeMinnerType == true
     */
    //clear to null
    // --------------------- student code ---------------------
    delete [] localTransArr;
    localTransArr=NULL;
    miningProcessTimer=0;
    if(changeMinnerType)
        workType=!workType;
    // ===================== student code =====================
}


void Minner::get_mining_process_reward()
{
    for (int i = 0; i < Minner::LOCAL_TRANSVEC_SIZE; i++) 
        revenue += localTransArr[i].fee;
}


bool Minner::update_mining_process()
{
    // check if mining process is completed in current timestamp
    /* return
     *   true: mining process has been finished.
     *   false: ining process is running.
     */

    // --------------------- student code ---------------------
/*    cout<<"minigProcessTimer: "<<miningProcessTimer<<endl;
    cout<<"10-computingPower: "<<10-computingPower<<endl;*/
    return (miningProcessTimer>=10-computingPower);
    // ===================== student code =====================
}


void Minner::set_id(int id) { this->id = id;} 
void Minner::set_workType(int workType) 
{ 
//    cout<<"got workType: "<<workType<<endl;
    this->workType = workType;
//    cout<<"stored workType: "<<this->workType<<endl;
}
void Minner::set_computingPower(int computingPower) { this->computingPower = computingPower; }
