#include <iostream>
#include <fstream>
#include <sstream>

#include "Minner.hpp"
#include "Transaction.hpp"

using namespace std;

void parse_tranfsaction_file(string filePath, Transaction **transArray, int &transArraySize)
{
    // use dynamic array to store transactions from transction file    
    // --------------------- student code ---------------------
    transArraySize=0;
//    cout<<"parse trans start"<<endl;
    ifstream in_file(filePath.c_str());
    string id,buyer,seller;
    double coinAmount,usDollar,fee;
    string mes;
    (*transArray)=new Transaction [200];
    while(getline(in_file,mes))
    {
        stringstream ss(mes);
        Transaction element;
        ss>>element.id>>element.fee>>element.buyer>>element.seller>>element.coinAmount>>element.usDollar;
        ss.clear();
//        cout<<"suvive input"<<endl;
//        cout<<transArraySize<<endl;
        (*transArray)[transArraySize]=element;
/*        Transaction* temp=new Transaction [transArraySize+1];
        cout<<"suvive temp declaration"<<endl;
        for(int i=0;i<transArraySize;i++)
        {
            temp[i]=(*transArray)[i];
            cout<<"suvive assignment"<<endl;
        }
        temp[transArraySize]=element;
        cout<<"survive new element"<<endl;
        if(transArraySize>0)
        {
            cout<<"survive delete"<<endl;
            delete [] (*transArray);
            (*transArray)=NULL;
        }
        (*transArray)=temp;
        cout<<"suvive pointer change"<<endl;*/
        transArraySize++;
    }
    in_file.close();
//    cout<<"parse trans end"<<endl;
    // ===================== student code =====================
}

void parse_minner_file(string filePath, Minner **minnerArray, int &minnerArraySize)
{
    // use dynamic array to store miners from miner file
    // --------------------- student code ---------------------
    minnerArraySize=0;
//    cout<<"parse minner start"<<endl;
    ifstream in_file(filePath.c_str());
    int id,workType,computingPower;
    string mes;
    (*minnerArray)=new Minner [200];
    while(getline(in_file,mes))
    {
        stringstream ss(mes);
        ss>>id>>workType>>computingPower;
        ss.clear();
/*        Minner* temp=new Minner [minnerArraySize+1];
        cout<<"survive temp"<<endl;
        for(int i=0;i<minnerArraySize;i++)
        {
            temp[i]=(*minnerArray)[i];
            cout<<"suvive assign"<<endl;
        }*/
        Minner element;
//        cout<<"element declared"<<endl;
        element.set_id(id);
//        cout<<"set id"<<endl;
        element.set_workType(workType);
//        cout<<"element workType: "<<element.getworkType()<<endl;
//        cout<<"set worktype"<<endl;
        element.set_computingPower(computingPower);
//        cout<<"set computing"<<endl;
        (*minnerArray)[minnerArraySize]=element;
//        cout<<"suvive element assignment"<<endl;
/*        temp[minnerArraySize]=element;
        cout<<"suvive new element"<<endl;

        if(minnerArraySize>0)
        {
            delete [] (*minnerArray);
            (*minnerArray)=NULL;
        }
        cout<<"survive delete"<<endl;
        (*minnerArray)=temp;
        cout<<"suvive pointer change"<<endl;*/
        minnerArraySize++;
    }
//    cout<<"input end"<<endl;

    //sort minnerArray
    for(int j=1;j<minnerArraySize;j++)
    {
        Minner key((*minnerArray)[j]);
        int i=j-1;
        while((i>=0)&&((*minnerArray)[i].getId()>key.getId()))
        {
            (*minnerArray)[i+1]=(*minnerArray)[i];
            i-=1;
        }
        (*minnerArray)[i+1]=key;
    }

/*    for(int i=0;i<minnerArraySize;i++)
    {
//        cout<<(*minnerArray)[i].getId()<<"th minner's worktype: "<<(*minnerArray)[i].getworkType()<<", computingPower: "<<(*minnerArray)[i].getcomputingPower()<<endl;
    }*/

//    cout<<"sort end"<<endl;
    in_file.close();
    // ===================== student code =====================
}


void get_minner_revenue(Minner *minner)
{
    // hint: this function can directly access private member of Miner class.
    cout << "Miner " << minner->id << "'s revenue: " << minner->revenue << endl;
}
