#include "Mempool.hpp"
#include "Transaction.hpp"

Mempool::Mempool(){}

Mempool::~Mempool()
{
    // --------------------- student code ---------------------
    delete [] (*transArray);
    transArray=NULL;
    delete [] (*minnerArray);
    minnerArray=NULL;
    // ===================== student code =====================
}

Mempool::Mempool(Transaction **transArray, int transArraySize, Minner **minnerArray, int minnerArraySize)
{
    this->transArray = transArray;
    this->transArraySize = transArraySize;
    this->minnerArray = minnerArray;
    this->minnerArraySize = minnerArraySize;

    // initialize each local transaction array (array's size is LOCAL_TRANSVEC_SIZE variable) of each miner
    // --------------------- student code ---------------------
    for(int i=0;i<minnerArraySize;i++)
    {
        (*minnerArray)[i].set_new_localTransArr((*transArray),transArraySize);
    }
    // ===================== student code =====================
   
}


void Mempool::delete_specific_transections(Transaction *completedTransArray, int completedTransArraySize)
{
    // delete completed transaction records in Mempool
    // hint: can use deep copy method to replace old transArray
    // --------------------- student code ---------------------
    int newSize=transArraySize-completedTransArraySize;
/*    if(newSize==0)
    {
        delete [] (*transArray);
        (*transArray)=NULL;
        return;
    }*/

    Transaction* newTransArray = new Transaction [newSize];
    int n_filled=0;
    for(int i=0;i<transArraySize;i++)
    {
        int pass=true;
        for(int j=0;j<completedTransArraySize;j++)
        {
//            cout<<i<<","<<j<<endl;
            if((*transArray)[i].id==completedTransArray[j].id)
            {
//                cout<<endl;
                pass=false;
                break;
            }
        }
        if(pass)
        {
            newTransArray[n_filled]=(*transArray)[i];
            n_filled++;
        }
//        cout<<n_filled<<endl;
        if(n_filled>=newSize)
            break;
    }

    transArraySize=newSize;
    delete [] (*transArray);
    (*transArray)=NULL;
    (*transArray)=newTransArray;
    // ===================== student code =====================
}


void Mempool::notify_other_minners(Minner *finishedMinner)
{
    /*
     * notify other miners, 
       stop miners that mine completed transactions 
       and delete completed transactions in mempool
       and reset the status of finishedMinner
     */   
    // --------------------- student code ---------------------
    
    //stop miners that mine completed transactions and delete completed transactions in mempool
    for(int i=0;i<minnerArraySize;i++)
    {
        if((*minnerArray)[i].id==(*finishedMinner).id)
            continue;
        if((*minnerArray)[i].check_transactions_in_localTransArr(finishedMinner->localTransArr, finishedMinner->LOCAL_TRANSVEC_SIZE))
        {
            (*minnerArray)[i].clear_localTransArr(true);
            (*minnerArray)[i].set_new_localTransArr((*transArray),transArraySize);
/*            cout<<"minner"<<(*minnerArray)[i].id<<endl;
            cout<<"workType after notify: "<<(*minnerArray)[i].workType<<endl;
            cout<<"localTransArr after notify: ";*/
/*            for(int i=0;i<2;i++)
                cout<<(*minnerArray)[i].localTransArr[i].id<<" ";
            cout<<endl;*/
        }
    }
    (*finishedMinner).clear_localTransArr(false); 
    (*finishedMinner).set_new_localTransArr((*transArray),transArraySize);
/*    cout<<"minner"<<finishedMinner->id<<endl;
    cout<<"workType after notify: "<<(*finishedMinner).workType<<endl;
    cout<<"localTransArr after notify: ";*/
/*    for(int i=0;i<2;i++)
        cout<<(*minnerArray)[i].localTransArr[i].id<<" ";
    cout<<endl;*/
    // ===================== student code =====================
}


void Mempool::update_block_chain()
{   
    // update all miners and check if any miner need to get new local transaction array
    // --------------------- student code ---------------------
//    cout<<"enter update block chain"<<endl;
    if((*transArray)==NULL)
    {
        return;
//        cout<<"transArray=NULL"<<endl;
    }
    for(int i=0;i<minnerArraySize;i++)
    {
//        cout<<"updating "<<i<<"th minner"<<endl;
        (*minnerArray)[i].updateTimer();
//        cout<<"update timer"<<endl;
        if((*minnerArray)[i].update_mining_process())
        {
/*            cout<<i+1<<"th minner finish mining"<<endl;
            cout<<"workType: "<<(*minnerArray)[i].workType<<endl;
            cout<<"finished trans id: "<<(*minnerArray)[i].localTransArr[0].id<<" "<<(*minnerArray)[i].localTransArr[1].id<<endl;*/
            (*minnerArray)[i].get_mining_process_reward();
//            cout<<"get reward"<<": ";
//            get_minner_revenue(&(*minnerArray)[i]);
//            cout<<endl;
            this->delete_specific_transections((*minnerArray)[i].localTransArr, (*minnerArray)[i].LOCAL_TRANSVEC_SIZE);
//            cout<<"delete specific trans"<<endl;
            this->notify_other_minners((*minnerArray)+i);
//            cout<<"notify"<<endl;
            if(transArraySize==0)
            {
//                cout<<"transArraySize=0"<<endl;
                return;
            }
        }
    }
    // ===================== student code =====================
}

